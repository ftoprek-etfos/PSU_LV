import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn import linear_model
from sklearn.metrics import r2_score
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_absolute_error, r2_score, mean_squared_error, max_error


df = pd.read_csv('cars_processed.csv')
df = df.drop('name',axis=1)

#df = df.drop('fuel',axis=1)
df = pd.get_dummies(df,columns=['fuel','transmission','seller_type','owner'],drop_first=True)

#x = df.drop('year',axis=1)
x = df.drop('selling_price',axis=1)
#x = x.drop('seats',axis=1)
y =  df['selling_price']

scaler = StandardScaler()
x = scaler.fit(x).transform(x.astype(float))
train, test, train_cijena, test_cijena = train_test_split(x,y, test_size = 0.05)

drugi_stupanj = PolynomialFeatures(2)
train_stupanj_dva = drugi_stupanj.fit_transform(train)

lr = linear_model.LinearRegression()
lr.fit(train_stupanj_dva, train_cijena)

test_stupanj_dva = drugi_stupanj.fit_transform(test)
y_test = lr.predict(test_stupanj_dva)

print("R2: ",r2_score(test_cijena,y_test))
print("Srednja apsolutna pogreska: ",mean_absolute_error(test_cijena,y_test))
print("Srednja kvadratna pogreska: ",mean_squared_error(test_cijena,y_test))
print("Najveca pogreska: ",max_error(test_cijena,y_test))


"""
Pogreska se povecava kada izbacujemo varijable iz skupa



R2:  0.851720987557559
Srednja apsolutna pogreska:  0.2105930572778346
Srednja kvadratna pogreska:  0.07571974278282373
Najveca pogreska:  1.0148470004628933

R2:  0.8446309207921614
Srednja apsolutna pogreska:  0.22233996403552309
Srednja kvadratna pogreska:  0.08565036898114414
Najveca pogreska:  1.3335352482555294

R2:  0.8114757249463391
Srednja apsolutna pogreska:  0.2317575485751995
Srednja kvadratna pogreska:  0.08536673566207545
Najveca pogreska:  0.8157330954851396

R2:  0.8443725624197833
Srednja apsolutna pogreska:  0.22694034521083084
Srednja kvadratna pogreska:  0.08071989301151887
Najveca pogreska:  1.045253114590551

R2:  0.7629484607447322
Srednja apsolutna pogreska:  0.2895110665554174
Srednja kvadratna pogreska:  0.14050980863244572
Najveca pogreska:  1.5272100099734658
"""