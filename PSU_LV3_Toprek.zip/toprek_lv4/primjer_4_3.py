import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ucitavanje ociscenih podataka
df = pd.read_csv('cars_processed.csv')
print(df.info())

sorted = df.sort_values(['selling_price'])
#print(sorted)
#print(df[df.year == 2012])
sorted = df.sort_values(['km_driven'])
#print(sorted)
#print(df['seats'].mean())
#print(df[df.fuel == 'Petrol'].km_driven.mean())
#print(df[df.fuel == 'Diesel'].km_driven.mean())


# razliciti prikazi
sns.pairplot(df, hue='fuel')

sns.relplot(data=df, x='km_driven', y='selling_price', hue='fuel')
df = df.drop(['name','mileage'], axis=1)

obj_cols = df.select_dtypes(object).columns.values.tolist()
num_cols = df.select_dtypes(np.number).columns.values.tolist()

fig = plt.figure(figsize=[15,8])
for col in range(len(obj_cols)):
    plt.subplot(2,2,col+1)
    sns.countplot(x=obj_cols[col], data=df)

df.boxplot(by ='fuel', column =['selling_price'], grid = False)

df.hist(['selling_price'], grid = False)

#tabcorr = df.corr()
#sns.heatmap(df.corr(), annot=True, linewidths=2, cmap= 'coolwarm') 

#plt.show()

"""
1. Koliko mjerenja (automobila) je dostupno u datasetu?
    DOSTUPNO JE 6699 AUTOMOBILA
2. Kakav je tip pojedinog stupca u dataframeu?
    OBJECT,INT64,FLOAT64
3. Koji automobil ima najveću cijenu, a koji najmanju?
    NAJVECU IMA BMW X7 xDrive 30d DPE, A NAJ MANJU Maruti 800 AC
4. Koliko automobila je proizvedeno 2012. godine?
    575 AUTOMOBILA
5. Koji automobil je prešao najviše kilometara, a koji najmanje?
    NAJVISE IMA Maruti Wagon R LXI Minor, A NAJMANJE IMA Maruti Eeco 5 STR With AC Plus HTR CNG
6. Koliko najčešće automobili imaju sjedala?
    NAJCESCE IMAJU 5 SJEDALA
7. Kolika je prosječna prijeđena kilometraža za automobile s dizel motorom, a koliko za automobile s benzinskim
motorom?
SA DIZEL MOTOROM 88039.97234392114 KM, A SA BENZINSKIM 54101.882809861534 KM
"""