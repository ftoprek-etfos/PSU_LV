import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

mt_cars = pd.read_csv('mtcars.csv');
print(mt_cars.sort_values(by=['mpg'])['car'].head(5));
print((mt_cars.sort_values(by=['mpg'],ascending=False).query('cyl == 8').head(3)));
print(mt_cars.query('cyl == 6')['mpg'].mean());
print(mt_cars.query('cyl == 4').query('wt >= 2.000' and 'wt <=2.200')['mpg'].mean());
print("Auta koji nisu automatici: " ,mt_cars.query('am == 0')['car'].count(),"\nAuti koji su automatici: ",mt_cars.query('am == 1')['car'].count());
print("Auta koji su automatici i snagom preko 100hp: " ,mt_cars.query('am == 1').query('hp > 100')['car'].count());
mt_cars['wt'] *= 453.59237;
print(mt_cars);



cyl4= mt_cars[(mt_cars.cyl == 4)]['mpg'].mean();
cyl6= mt_cars[(mt_cars.cyl == 6)]['mpg'].mean();
cyl8= mt_cars[(mt_cars.cyl == 8)]['mpg'].mean();
df = pd.DataFrame({'cyl':['4', '6', '8'], 'val':[cyl4,cyl6,cyl8]})
ax = df.plot.bar(x='cyl', y='val', rot=0)
plt.show();

cyl4= mt_cars[(mt_cars.cyl == 4)]['wt'].mean();
cyl6= mt_cars[(mt_cars.cyl == 6)]['wt'].mean();
cyl8= mt_cars[(mt_cars.cyl == 8)]['wt'].mean();
df = pd.DataFrame({'cyl':['4', '6', '8'], 'val':[cyl4,cyl6,cyl8]})
plt.show();