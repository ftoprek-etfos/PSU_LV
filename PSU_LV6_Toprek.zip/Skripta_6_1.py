import numpy as np
from sklearn.datasets import fetch_openml
import joblib
import pickle
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPClassifier
from sklearn import metrics
import seaborn as sns
import ssl
ssl._create_default_https_context = ssl._create_unverified_context

X, y = fetch_openml('mnist_784', version=1, return_X_y=True, as_frame=False)

# TODO: prikazi nekoliko ulaznih slika
img = np.asarray(X)

fig = plt.figure(figsize=(8, 8))
for i in range(1, 3*3 +1):
    fig.add_subplot(3, 3, i)
    first_image = img[i]
    first_image = np.array(first_image, dtype='float')
    pixels = first_image.reshape((28, 28))
    plt.imshow(pixels, cmap='gray')
plt.show()

# skaliraj podatke, train/test split
X = X / 255.
X_train, X_test = X[:60000], X[60000:]
y_train, y_test = y[:60000], y[60000:]

# TODO: izgradite vlastitu mrezu pomocu sckitlearn MPLClassifier 
mlp = MLPClassifier(hidden_layer_sizes=(50, ), max_iter=10, alpha=1e-4, solver='sgd', verbose=10, random_state=1, learning_rate_init=.1,activation='logistic')    
mlp.fit(X_train, y_train)

# TODO: evaluirajte izgradenu mrezu
print("Training set score:", mlp.score(X_train, y_train).round(4))
print("Test set score:", mlp.score(X_test, y_test).round(4))

predictions = mlp.predict(X_test)

cm = metrics.confusion_matrix(y_true=y_test, 
                         y_pred = predictions, 
                        labels = mlp.classes_)

print(cm)

plt.figure(figsize=(10,10))
sns.heatmap(cm, annot=True, linewidths=.5, square = True, cmap = 'Blues_r')

plt.ylabel('Actual label')
plt.xlabel('Predicted label')
all_sample_title = 'Accuracy Score: {0}'.format(mlp.score(X_test, y_test))
plt.title(all_sample_title)
plt.show()
# spremi mrezu na disk
filename = "NN_model.sav"
joblib.dump(mlp, filename)

