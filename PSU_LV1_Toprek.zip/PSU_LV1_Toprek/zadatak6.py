spam = 0
spamb = 0
ham = 0
hamb = 0
usklicnik = 0
for line in open("SMSSpamCollection.txt"):
    if(line.startswith("spam")):
        line = line.split("spam ")[0]
        spam+=1
        if(line.endswith("!\n")):
            usklicnik+=1
        for a in line:
            spamb+=1
    if(line.startswith("ham")):
        line = line.split("ham ")[0]
        ham+=1
        for a in line:
            hamb+=1
print("Prosjecan brojr rijeci u spam je ",round(spamb/spam,2),",a prosjecan broj rijeci u ham je ",round(hamb/ham,2))
print(usklicnik," poruka tipa spam zavrsava na usklicnik")