a=-1
try:
    while(a < 0.0 or a > 1.0):
        a = float(input("Unesite ocjenu: "))
    if(a < 0.6):
        print("F")
    elif(a >=0.6 and a < 0.7):
        print("D")
    elif(a >=0.7 and a < 0.8):
        print("C")
    elif(a >=0.8 and a < 0.9):
        print("B")
    elif(a >=0.9 and a <= 1.0):
        print("A")
except:
    print("Korisnik nije unjeo broj")