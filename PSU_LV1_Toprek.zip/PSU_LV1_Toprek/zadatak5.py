rijecnik = {}
for line in open("song.txt"):
    b = line.split(" ")
    for a in b:
        if(rijecnik.setdefault(a)):
            rijecnik[a] +=1
        else:
            rijecnik[a] = 1
print(rijecnik)