def total_euro(r,e):
    return r*e;

a = int(input("Unesite broj radnih sati: "))
b = float(input("Unesite koliko ste placeni po satu u eurima: "))

print("Ukupno: " ,total_euro(a,b)," eura")