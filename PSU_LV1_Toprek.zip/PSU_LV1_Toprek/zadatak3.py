lista = []
a = ""
while(a != "Done"):
    a = input()
    try:
        a = int(a)
        lista.append(a)
    except:
        if(a != "Done"):
            print("Niste unjeli broj")
c=0
print(len(lista))
for b in lista:
    c+=int(b);
print(c/len(lista))
print(max(lista))
print(min(lista))