a = input("Ime datoteke: ")
b = 0
c = 0
for line in open(a):
    if(line.startswith("X-DSPAM-Confidence:")):
        b += float(line.split("X-DSPAM-Confidence: ")[1])
        c+=1
print(b/c)