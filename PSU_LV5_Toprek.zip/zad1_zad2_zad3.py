
from funkcija_5_1 import generate_data
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from scipy.cluster.hierarchy import dendrogram, linkage

scores = []
X = generate_data(n_samples=500, flagc=1)

kmeans = KMeans(n_clusters=3)
kmeans.fit(X)

labels = kmeans.predict(X)
boje = ['green', 'purple', 'blue']

obojano = [boje[label] for label in labels]

plt.scatter(X[:,0], X[:,1], color=obojano)
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], color='red', marker='*', s=100)
plt.show()

for i in range(1, 21):
    kmeans = KMeans(n_clusters=i, random_state=42).fit(X)
    score = kmeans.score(X)
    scores.append(abs(score))

plt.plot(range(1, 21), scores, marker='o')
plt.xlabel('Broj klastera')
plt.ylabel('Vrijednost kriterijske funkcije')
plt.show()

link = linkage(X, method='single')

plt.figure(figsize=(10, 5))
dendrogram(link,truncate_mode="level", p=3)
plt.show()

# Generira se drugacije tockice svaki puta kada pokrenemo program
# Mijenja se način kako su nasumični podatci grupirani
# Pomoću lakat metode možemo odrediti optimalni broj klaastera to bi bilo 3
# Dendrogram je dijagram koji prikazuje udaljenosti atributa između svakog para sekvencijalno spojenih klasa. 
# Kako bi se izbjeglo križanje linija, dijagram je grafički raspoređen tako da su članovi svakog para klasa koje se spajaju susjedi u dijagramu. 
# Alat Dendrogram koristi hijerarhijski algoritam klasteriranja.
# Broj klastera "k" često je unaprijed određen od strane korisnika, a klasteri se dodjeljuju rezanjem dendrograma na određenoj dubini što rezultira "k" grupama manjih dendrograma
