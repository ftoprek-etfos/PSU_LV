import matplotlib.image as mpimg
import numpy as np
import matplotlib.pyplot as plt
from sklearn import cluster

image = mpimg.imread('example_grayscale.png')
clusters = 10

X = image.reshape((-1, 1))
k_means = cluster.KMeans(n_clusters=clusters,n_init=1)
k_means.fit(X) 

values = k_means.cluster_centers_.squeeze()
labels = k_means.labels_
image_compressed = np.choose(labels, values)
image_compressed.shape = image.shape

plt.figure(1)
plt.imshow(image,  cmap='gray')
plt.show()

plt.figure(2)
plt.imshow(image_compressed,  cmap='gray')
plt.show()

# Slika je postala malo tamnija te vecina detalja slike je idalje zadrzana kao i u originalu
# Što manje klastera postavimo to će veća kompresija biti odnosno gubi se informacija sa slike
# 10 bitova (koji pokrivaju do 1024 vrijednosti) za kodiranje svakog piksela u našoj novoj paleti boja 1000
# naša slika koristi 8 bitni grayscale sto znaci da je kompresija 8 / 10 = 0,8
# što znači da umjesto 8 bita za pixel koristiti će se 1 (0.8) bit po pixelu 