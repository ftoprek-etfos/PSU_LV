import numpy as np
import matplotlib.pyplot as plt

data = np.loadtxt(open("mtcars.csv", "rb"), usecols=(1,2,3,4,5,6), delimiter=",", skiprows=1)
x = []
y = []
wt = []
cil = []
for i in data:
    x.append(i[0])
    y.append(i[3])
    wt.append(i[5])
    cil.append(i[1])
normalizedData = (wt-np.min(wt))/(np.max(wt)-np.min(wt))*100

plt.scatter(x,y, c="red", s=normalizedData)
plt.xlabel("mpg")
plt.ylabel("hp")
print("Minimalna potrosnja: ",min(x))
print("Maximalna potrosnja: ",max(x))
print("Srednja potrosnja: ",sum(x)/len(x))
sestcil = []
j=0;
for i in cil:
    if(i == 6):
        sestcil.append(x[j])
    j +=1;
print("Minimalna potrosnja: ",min(sestcil))
print("Maximalna potrosnja: ",max(sestcil))
print("Srednja potrosnja: ",sum(sestcil)/len(sestcil))
plt.show()

